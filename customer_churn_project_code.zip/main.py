from data_preprocessing import load_and_clean
from model_training import train_model

if __name__ == "__main__":
    print("Running Customer Churn Project...")
    train_model("customer_churn.csv")
