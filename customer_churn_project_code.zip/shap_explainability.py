import pandas as pd
import joblib
import shap
import matplotlib.pyplot as plt

model = joblib.load("churn_model.pkl")
df = pd.read_csv("customer_churn.csv")

X = df.drop("Churn", axis=1)
X = pd.get_dummies(X)

explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X)

shap.summary_plot(shap_values, X, show=False)
plt.savefig("shap_summary.png")
print("SHAP plot saved as shap_summary.png")
