import pandas as pd

def load_and_clean(path):
    df = pd.read_csv(path)
    df = df.dropna()
    return df

if __name__ == "__main__":
    df = load_and_clean("customer_churn.csv")
    print(df.head())
